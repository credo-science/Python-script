import os
import sys
import json
from bson import json_util, ObjectId


#struktura słownika: timestamp_id : detekcja
slownik = dict()
sciezka_dla_plikow_wynikowych = 'polaczone/'


def load_from_json_file(file_path):
    try:
        print(file_path)
      
        if os.path.exists(file_path):
            with open(file_path) as json_file:
                content = json.load(json_file)

        for item in content['detections']:
            zaktualizuj_slownik_dict(item)

    except Exception as e:
        print('[load_from_json_file] Exception: %s'%e)


#dodanie do slownika calego elemntu tj. detekcji
def zaktualizuj_slownik_dict(item):
    key = '%d_%d'%(item['timestamp'],item['id'])
    slownik[key] = item


def zapisz_slownik_do_pliki(path,year,month,day,slownik):

    path_to_file = przygotuj_sciezke(path,year,month,day)

    output = {'detections':[]}
    #posortowanie istniejacego slownika wg. timestamp_id

    slownik = dict(sorted(slownik.items()))

    print(slownik.values())
    #przygotowanie listy uporzadkowanych detekcji, timestamp_id tylko do iteracji
    for key,value in slownik.items():
        output['detections'].append(value)

    json_object = json.loads(json_util.dumps(output))

    with open(path_to_file,'w') as json_file:
        json.dump(json_object, json_file, indent=4)


def przygotuj_sciezke(path,year,month,day):
    if day <10:
        day = '0%d'%day
    if month < 10:
        month = '0%d'%month
    
    file_name = 'detections_'+str(year)+'-'+str(month)+'-'+str(day)
    path_to_file = path+'/'+file_name

    if os.path.exists(path) == False:
        os.makedirs(path, exist_ok=True)
    
    return path_to_file


def main():

    lokalizacja_plikow = 'dobre_czasowo/2020/01/10'
    lista_plikow_z_folderu = os.listdir(lokalizacja_plikow)
    lista_plikow_z_folderu.sort()

    for plik in lista_plikow_z_folderu:
        file_path = lokalizacja_plikow +'/'+plik
        load_from_json_file(file_path)

    print(len(slownik))

    zapisz_slownik_do_pliki(sciezka_dla_plikow_wynikowych,2020,1,10,slownik)


if __name__ == "__main__":
    main()