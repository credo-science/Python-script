"""
#_______________________________________________________________________________________________
#                               INFORMACJE WSTĘPNE
#
TRZECIA CZĘŚĆ FILTROWANIA - ŁĄCZENIE JSONOW W 1 PLIK Z 1 DNIA ORAZ PODSUMOWANIE

"""

#BIBLIOTEKI PODSTAWOWE
import io
import json
import os
from os import listdir
from os.path import isfile, join,isdir
from datetime import datetime, timedelta
import time
import shutil#do usuwania folderu
import fnmatch#lepsze listowanie plików
import sys
from bson import json_util, ObjectId
#SCIEZKI
home = os.path.dirname(os.path.abspath(__file__))+"/"
sciezka_analizy=home+"dobre_graficznie/"
sciezka_zapisu=home+"po_filtrze/"


slownik = dict()

#wstepne wartosci
rok=2018
miesiac="06"
dzien=13
LICZBA = {'suma':0}

"""
kontynuacja_pracy() to wczytanie pliku w którym jest podana
data od której mamy zacząć analize po wznowieniu pracy
"""
def kontynuacja_pracy():
    try:
        informacja=open(home+"info_start_laczenia.txt",'r')
        informacja=informacja.read()
        info=informacja.split("-")
        #zacznij od
        rok=info[0]
        miesiac=int(info[1])
        dzien=int(info[2])
        if dzien <10:
            dzien="0"+str(dzien)
        if miesiac <10:
            miesiac="0"+str(miesiac)
        miesiac=str(miesiac)
        dzien=str(dzien)
        print(rok,miesiac,dzien)
        cykl_dnia(rok,miesiac,dzien)


    except Exception as e:
        print('bład dla dnia: %s'%e)
    kontynuacja_pracy()


def cykl_dnia(rok,miesiac,dzien):
    dodatek=str(rok)+"/"+miesiac+"/"+str(dzien)+"/"
    zrodlo=sciezka_analizy+dodatek

    lista_plikow_z_folderu = [x for x in listdir(zrodlo) if fnmatch.fnmatch(x,'*.json')]
    lista_plikow_z_folderu.sort()

    for plik in lista_plikow_z_folderu:
        file_path = zrodlo +plik
        load_from_json_file(file_path)

    liczba=0
    zapisz_slownik_do_pliki(sciezka_zapisu,rok,miesiac,dzien,slownik)
    slownik.clear()
    update_info(rok,miesiac,dzien)


def aktualizuj_liczbe(liczba):
    LICZBA['suma'] += liczba
    aktualizuj=open(home+"info_do_dnia.txt",'w')
    aktualizuj.write("detekcji dobrych po filtrze antyartefaktowym: "+str(LICZBA['suma']))
    aktualizuj.close()


def update_info(rok,miesiac,dzien):
    datestr = str(rok)+"-"+str(miesiac)+"-"+str(dzien)
    format =  '%Y-%m-%d'

    data=datetime.strptime(datestr, format) + timedelta(days=1)

    aktualizuj=open(home+"info_start_laczenia.txt",'w')
    aktualizuj.write(str(data.date()))
    aktualizuj.close()

def load_from_json_file(file_path):
    try:
        #print(file_path)

        if os.path.exists(file_path):
            with open(file_path) as json_file:
                content = json.load(json_file)

        for item in content['detections']:
            zaktualizuj_slownik_dict(item)

    except Exception as e:
        print('[load_from_json_file] Exception: %s'%e)


#dodanie do slownika calego elemntu tj. detekcji
def zaktualizuj_slownik_dict(item):
    key = '%d_%d'%(item['timestamp'],item['id'])
    slownik[key] = item


def zapisz_slownik_do_pliki(path,year,month,day,slownik):

    path_to_file = przygotuj_sciezke(path,year,month,day)
    output = {'detections':[]}
    #posortowanie istniejacego slownika wg. timestamp_id

    slownik = dict(sorted(slownik.items()))

    #print(slownik.values())
    #przygotowanie listy uporzadkowanych detekcji, timestamp_id tylko do iteracji
    for key,value in slownik.items():
        output['detections'].append(value)

    json_object = json.loads(json_util.dumps(output))

    with open(path_to_file+".json",'w') as json_file:
        json.dump(json_object, json_file, indent=4)


    liczba=len(slownik)
    zaktualizuj(int(year),int(month),int(day),liczba)
    aktualizuj_liczbe(liczba)

    slownik.clear()

def przygotuj_sciezke(path,year,month,day):
    file_name = str(year)+'/detections_'+str(year)+'-'+str(month)+'-'+str(day)
    path_to_file = path+file_name
    path+=str(year)
    if os.path.exists(path) == False:
        os.makedirs(path, exist_ok=True)
    return path_to_file


def main():
    kontynuacja_pracy()

def zaktualizuj(rok,miesiac,dzien,liczbas):
    aktualizuj=open(home+"info_koncowe.txt",'a')
    aktualizuj.write("%s-%s-%s: %d\n"%(rok,miesiac,dzien,liczbas))
    aktualizuj.close()

    aktualizuj=open(home+"info_koncowe2.txt",'a')
    aktualizuj.write(str(liczbas)+"\n")
    aktualizuj.close()


if __name__ == '__main__':
    main()
    aktualizuj=open(home+"info_koncowe.txt",'a')
    aktualizuj.write("detekcji dobrych po filtrze antyartefaktowym: "+str(LICZBA['suma']))
    aktualizuj.close()
