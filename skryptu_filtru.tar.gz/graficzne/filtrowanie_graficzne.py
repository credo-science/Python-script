"""
#_______________________________________________________________________________________________
#                               INFORMACJE WSTĘPNE
#
DRUGA CZĘŚĆ DO FILTROWANIA

CZESC ANALIZY GRAFICZNEJ FILTRU:
JASNYCH PIKSELI W MATRYCY -70
NAJJASNIEJSZY PIKSEL CONAJMNIEJ -70

SKALA JASNOSCI (0 CZERN DO 255 BIEL)
"""

#BIBLIOTEKI PODSTAWOWE
import io
import json
import os
from os import listdir
from os.path import isfile, join,isdir
from datetime import datetime, timedelta
import time
import shutil#do usuwania folderu
import fnmatch#lepsze listowanie plików

#BIBLIOTEKI ANALIZY GRAFICZNEJ
import base64
from PIL import Image
Image.LOAD_TRUNCATED_IMAGES = True
from bson import json_util, ObjectId
#SCIEZKI
home = os.path.dirname(os.path.abspath(__file__))+"/"
sciezka_analizy=home+"dobre_czasowo/"
sciezka_zapisu=home+"dobre_graficznie/"
sciezka_robocza=home+"robocze/"



os.makedirs(sciezka_robocza,exist_ok=True)
#wstepne wartosci
rok=2018
miesiac="06"
dzien=13

global detekcje_dobre
detekcje_dobre=[]
"""
kontynuacja_pracy() to wczytanie pliku w którym jest podana
data od której mamy zacząć analize po wznowieniu pracy
"""
def kontynuacja_pracy():
    informacja=open(home+"info_start_graficzne.txt",'r')
    informacja=informacja.read()
    info=informacja.split("-")
    #zacznij od
    rok=info[0]
    miesiac=info[1]
    dzien=int(info[2])
    if dzien <10:
        dzien="0"+str(dzien)
    print(rok,miesiac,dzien)
    cykl_dnia(rok,miesiac,dzien)
    kontynuacja_pracy()

def cykl_dnia(rok,miesiac,dzien):
    dodatek=str(rok)+"/"+miesiac+"/"+str(dzien)+"/"
    zrodlo=sciezka_analizy+dodatek
    lista_urzadzen = [x for x in listdir(zrodlo) if fnmatch.fnmatch(x,'*.json')]
    if len(lista_urzadzen)>0:
        for nazwa in lista_urzadzen:
            plik=zrodlo+nazwa
            filtr_graficzny(dodatek,nazwa,plik)#analiza graficzna filtru w 1 urzadzeniu - 1 dzien


        update_info(rok,miesiac,dzien)
    else:
        print("brak urządzeń w podanej dacie, tj : ",rok,"-",miesiac,"-",dzien)


def filtr_graficzny(dodatek,nazwa,plik):
    with open(plik) as f:
        json_from_file = json.load(f)
    dobre=0
    zle=0
    for detection in json_from_file['detections']:
        device_id = int(detection['device_id'])
        frame_content = detection['frame_content']
        idczek = int(detection['id'])
        obrazek = frame_content.encode('ascii')
        adres=sciezka_robocza+str(idczek)+".png"

        with open(adres, "wb") as fh:
            fh.write(base64.decodebytes(obrazek))
        try:
            im = Image.open(adres).convert('LA')
            pixelMap = im.load()

            pixelMap = im.load()
            img = Image.new( im.mode, im.size)
            pixelsNew = img.load()
            progtla=70
            jasnychpixeli=71
            jasnypunkt=0
            suma_tla=0
            najjasniejszypunkt=0
            najjasniejszypunkt2=0
            for w in range(img.size[0]):
                 for j in range(img.size[1]):
                    a=pixelMap[w,j]#a -tablica pixela ((p),(t)) interesuje nas tylko p; t zawsze ==255
                    a0=a[0]
                    suma_tla+=a0
                    if najjasniejszypunkt<a0:
                        najjasniejszypunkt2=najjasniejszypunkt
                        najjasniejszypunkt=a0
                    if progtla <a0:
                        jasnypunkt+=1

            if (jasnypunkt>0 and jasnypunkt<jasnychpixeli):
                detekcje_dobre.append(detection)
                dobre+=1
            else:
                zle+=1
            if os.path.isfile(adres) :
                os.remove(adres)
        except IOError:
            pass
    #print("dobre: ",dobre)
    #print("zle: ",zle)
    zapisanie_detekcji_urzadzenia(dodatek,nazwa,detekcje_dobre)
    detekcje_dobre.clear()

def zapisanie_detekcji_urzadzenia(data,urzadzenie,baza_detekcji):
    full_sciezka_zapisu=sciezka_zapisu+data+urzadzenie
    os.makedirs(sciezka_zapisu+data,exist_ok=True)
    with open(full_sciezka_zapisu,'w') as json_file:#zapisujemy dobre detekcje do jsona
        dictionary = {'detections':[]}
        dictionary['detections'] = baza_detekcji
        json_object = json.loads(json_util.dumps(dictionary))
        json.dump(json_object, json_file, indent=4)
    detekcje_dobre=[]
    baza_detekcji=[]
    json_object.clear()

def update_info(rok,miesiac,dzien):
    datestr = str(rok)+"-"+str(miesiac)+"-"+str(dzien)
    format =  '%Y-%m-%d'

    data=datetime.strptime(datestr, format) + timedelta(days=1)

    aktualizuj=open(home+"info_start_graficzne.txt",'w')
    aktualizuj.write(str(data.date()))
    aktualizuj.close()

def main():
    kontynuacja_pracy()

if __name__ == '__main__':
    main()
